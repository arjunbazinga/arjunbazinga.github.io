Ancillary files for "A Hilbert curve for the spectre".

lean/                       Lean 4 proof of Theorem 3 (lake build; Lean 4.15.0, core library only). See lean/README.md.
43_route_certificate.py     The certificate of Section 4.1 (junctions named by routes), exact integer arithmetic.
                            python3 43_route_certificate.py rule_Bsym.json
independent_check.py        The address form of the certificate, Python standard library only.
                            python3 independent_check.py rule_Bsym_levels2up.json   (32-state rule)
                            python3 independent_check.py rule_min30.json            (30-state rule)
rule_*.json                 The rules.

All other scripts: see Appendix B and the repository named under "Code and data".
