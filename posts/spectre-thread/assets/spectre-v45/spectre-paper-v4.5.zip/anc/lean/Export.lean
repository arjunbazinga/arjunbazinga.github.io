import Spectre.Defs
def fmt (t : Poly) : String := String.intercalate ";" (t.map fun p => s!"{p.a} {p.b} {p.c} {p.d}")
def dump (X : Shape) (n : Nat) (name : String) : IO Unit := do
  for t in tiles X n do IO.println s!"{name} {n} {fmt t}"
#eval do for n in [0, 1, 2, 3, 4] do dump .D n "D"; dump .G n "G"
