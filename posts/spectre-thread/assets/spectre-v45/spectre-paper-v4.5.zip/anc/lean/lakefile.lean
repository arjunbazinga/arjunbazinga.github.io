import Lake
open Lake DSL

package spectre

@[default_target]
lean_lib Spectre
