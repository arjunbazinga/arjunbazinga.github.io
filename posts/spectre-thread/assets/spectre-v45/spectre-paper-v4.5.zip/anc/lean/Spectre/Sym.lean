/- Symbolic translations: evaluation, the shift between levels, and the recurrence. -/
import Spectre.Natural
open ZOps
set_option maxRecDepth 100000

@[simp] theorem Q4_add {α : Type} [ZOps α] (x y : Q4 α) : (add x y : Q4 α) = ⟨add x.p0 y.p0, add x.p1 y.p1, add x.p2 y.p2, add x.p3 y.p3⟩ := rfl
@[simp] theorem Q4_neg {α : Type} [ZOps α] (x : Q4 α) : (neg x : Q4 α) = x.map neg := rfl
@[simp] theorem Q4_zero {α : Type} [ZOps α] : (zero : Q4 α) = ⟨zero, zero, zero, zero⟩ := rfl
@[simp] theorem Q4_zmul {α : Type} [ZOps α] (x : Q4 α) : (zmul x : Q4 α) = x.map zmul := rfl
@[simp] theorem Q4_refl {α : Type} [ZOps α] (x : Q4 α) : (refl x : Q4 α) = x.map refl := rfl

theorem ev_hom (q : Q4 P) : IsHom (ev q) where
  add K L := by simp only [ev, linApp, P.smul, Q4_add, P_add]; ext <;> ring'
  neg K := by simp only [ev, linApp, P.smul, Q4_neg, Q4.map, P_add, P_neg]; ext <;> ring'
  zero := by simp only [ev, linApp, P.smul, Q4_zero, P_add, P_zero]; ext <;> simp
  zmul K := by simp only [ev, linApp, P.smul, Q4_zmul, Q4.map, P_add, P_zmul]; ext <;> ring'
  refl K := by simp only [ev, linApp, P.smul, Q4_refl, Q4.map, P_add, P_refl]; ext <;> ring'

theorem QSYM_ev (q : Q4 P) : QSYM.map (ev q) = q := by
  simp only [QSYM, Q4.map, ev, linApp, P.smul, E4, Z4, P_add, P_zero]
  ext <;> simp

theorem placements_eval (q : Q4 P) : placements q = (placements QSYM).map (Aff.map (ev q)) := by
  have := (ev_hom q).placements QSYM; rwa [QSYM_ev] at this

theorem superQuad_eval (q : Q4 P) : superQuad q = SQ.map (ev q) := by
  have := (ev_hom q).superQuad QSYM; rwa [QSYM_ev] at this

theorem place_eq (n j : Nat) : place n j = evA (quad n) (TS j) := by
  simp only [place, TS, evA, placements_eval]
  rw [← (ev_hom (quad n)).id', getD_map]

theorem ev_compL (q : Q4 P) (L : Q4 P) (S : Sym) : ev q (compL L S) = linApp L (ev q S) := by
  simp only [ev, compL, linApp, Q4.map, P.smul, P_add]; ext <;> ring'

theorem ev_shiftM (q : Q4 P) (K : Sym) : ev q (shiftM K) = ev (superQuad q) K := by
  simp only [shiftM, (ev_hom q).add, ev_compL, superQuad_eval]; rfl

theorem evA_shift (n : Nat) (A : Aff Sym) : evA (quad n) (shiftA A) = evA (quad (n + 1)) A := by
  simp only [evA, shiftA, Aff.map, ev_shiftM]; rfl

/-! Linearity in the key points, and the recurrence. -/
def Q4.smul (c : Int) (q : Q4 P) : Q4 P := q.map (P.smul c)

theorem ev_addq (q q' : Q4 P) (K : Sym) : ev (add q q') K = add (ev q K) (ev q' K) := by
  simp only [ev, linApp, P.smul, Q4_add, P_add]; ext <;> ring'
theorem ev_smulq (c : Int) (q : Q4 P) (K : Sym) : ev (Q4.smul c q) K = P.smul c (ev q K) := by
  simp only [ev, linApp, P.smul, Q4.smul, Q4.map, P_add]; ext <;> ring'
theorem ev_negq (q : Q4 P) (K : Sym) : ev (neg q) K = neg (ev q K) := by
  simp only [ev, linApp, P.smul, Q4_neg, Q4.map, P_add, P_neg]; ext <;> ring'
theorem ev_zeroq (K : Sym) : ev zero K = zero := by
  simp only [ev, linApp, P.smul, Q4_zero, P_add, P_zero]; ext <;> simp

def comb (x y z w : Q4 P) : Q4 P := add (add x (Q4.smul (-9) y)) (add (Q4.smul 9 z) (neg w))

theorem ev_comb (x y z w : Q4 P) (K : Sym) :
    ev (comb x y z w) K = add (add (ev x K) (P.smul (-9) (ev y K))) (add (P.smul 9 (ev z K)) (neg (ev w K))) := by
  simp only [comb, ev_addq, ev_smulq, ev_negq]

theorem superQuad_comb (x y z w : Q4 P) :
    superQuad (comb x y z w) = comb (superQuad x) (superQuad y) (superQuad z) (superQuad w) := by
  simp only [superQuad_eval]
  apply Q4.ext <;> simp only [Q4.map] <;> rw [ev_comb] <;> simp only [comb, Q4_add, Q4.smul, Q4_neg, Q4.map]

theorem superQuad_zero : superQuad (zero : Q4 P) = zero := by
  simp only [superQuad_eval, Q4.map, ev_zeroq]; rfl

theorem quad_rec0 : comb (quad 6) (quad 4) (quad 2) (quad 0) = zero := by decide +kernel

theorem quad_rec (n : Nat) : comb (quad (n + 6)) (quad (n + 4)) (quad (n + 2)) (quad n) = zero := by
  induction n with
  | zero => exact quad_rec0
  | succ n ih =>
    show comb (superQuad (quad (n + 6))) (superQuad (quad (n + 4))) (superQuad (quad (n + 2))) (superQuad (quad n)) = zero
    rw [← superQuad_comb, ih, superQuad_zero]

/-- Six consecutive levels determine a symbolic translation at every level. -/
theorem ev_quad_zero (D : Sym) (h : ∀ m, m < 6 → ev (quad m) D = zero) : ∀ n, ev (quad n) D = zero := by
  intro n
  induction n using Nat.strongRecOn with
  | ind n ih =>
    by_cases hn : n < 6
    · exact h n hn
    · obtain ⟨m, rfl⟩ : ∃ m, n = m + 6 := ⟨n - 6, by omega⟩
      have e := congrArg (fun q => ev q D) (quad_rec m)
      simp only [ev_comb, ev_zeroq] at e
      rw [ih (m + 4) (by omega), ih (m + 2) (by omega), ih m (by omega)] at e
      simp only [P.smul, P_add, P_neg, P_zero, P.mk.injEq] at e
      ext <;> simp only [P_zero] <;> omega

theorem same_spec {A B : Aff Sym} (h : same A B = true) (n : Nat) (x : P) :
    (evA (quad n) A).app x = (evA (quad n) B).app x := by
  simp only [same, Bool.and_eq_true, beq_iff_eq, List.all_cons, List.all_nil, Bool.and_true] at h
  have hk := h.1.1; have hr := h.1.2; have h0 := h.2.1; have h1 := h.2.2.1; have h2 := h.2.2.2.1
  have h3 := h.2.2.2.2.1; have h4 := h.2.2.2.2.2.1; have h5 := h.2.2.2.2.2.2
  have hD : ∀ m, ev (quad m) (add A.t (neg B.t)) = zero := by
    apply ev_quad_zero
    intro m hm
    rw [(ev_hom _).add, (ev_hom _).neg]
    have : ev (quad m) A.t = ev (quad m) B.t := by
      match m, hm with
      | 0, _ => exact h0 | 1, _ => exact h1 | 2, _ => exact h2 | 3, _ => exact h3 | 4, _ => exact h4 | 5, _ => exact h5
    rw [this]; ext <;> simp <;> omega
  have ht : ev (quad n) A.t = ev (quad n) B.t := by
    have := hD n; rw [(ev_hom _).add, (ev_hom _).neg] at this
    simp only [P_add, P_neg, P_zero, P.mk.injEq] at this
    ext <;> omega
  simp only [evA, Aff.map, Aff.app, lin, hk, hr, ht]
