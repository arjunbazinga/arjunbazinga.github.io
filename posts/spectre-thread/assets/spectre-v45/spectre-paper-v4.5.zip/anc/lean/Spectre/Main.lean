/- The main theorem: for every state of the rule and every level n, the path visits each tile of the level-n
supertile once, consecutive tiles share an edge, and each sub-supertile is one contiguous run. -/
import Spectre.Sym
open ZOps
set_option maxRecDepth 100000

/-! ## The certificate, checked by the kernel -/
theorem checkRule_ok : checkRule = true := by decide +kernel
theorem checkBase_ok : checkBase = true := by decide +kernel
theorem checkSib_ok : checkSib = true := by decide +kernel
theorem checkClosed_ok : checkClosed = true := by decide +kernel
theorem checkMystic_ok : checkMystic = true := by decide +kernel
theorem checkAddr_ok : checkAddr = true := by decide +kernel

/-! ## Lists -/
section lists
variable {α β : Type}

theorem getLastD_indep (l : List α) (h : l ≠ []) (d d' : α) : l.getLastD d = l.getLastD d' := by
  cases l with
  | nil => exact absurd rfl h
  | cons x xs => rfl

theorem getLastD_append (a b : List α) (d : α) : (a ++ b).getLastD d = b.getLastD (a.getLastD d) := by
  induction a generalizing d with
  | nil => rfl
  | cons x a ih => simp only [List.cons_append, List.getLastD_cons, ih]

theorem headD_append (a b : List α) (d : α) (h : a ≠ []) : (a ++ b).headD d = a.headD d := by
  cases a with
  | nil => exact absurd rfl h
  | cons x xs => rfl

theorem getLastD_mem (l : List α) (h : l ≠ []) (d : α) : l.getLastD d ∈ l := by
  induction l generalizing d with
  | nil => exact absurd rfl h
  | cons x xs ih =>
    cases xs with
    | nil => simp
    | cons y ys => exact List.mem_cons_of_mem _ (ih (by simp) x)

theorem headD_mem (l : List α) (h : l ≠ []) (d : α) : l.headD d ∈ l := by
  cases l with
  | nil => exact absurd rfl h
  | cons x xs => simp

theorem flatMap_last (l : List β) (g : β → List α) (d : β) (hl : l ≠ []) (hg : ∀ x ∈ l, g x ≠ []) (e : α) :
    (l.flatMap g).getLastD e = (g (l.getLastD d)).getLastD e := by
  induction l generalizing d with
  | nil => exact absurd rfl hl
  | cons x xs ih =>
    cases xs with
    | nil => simp
    | cons y ys =>
      rw [List.flatMap_cons, getLastD_append, List.getLastD_cons]
      have hne : (y :: ys).flatMap g ≠ [] := by
        rw [List.flatMap_cons]; intro h; exact hg y (by simp) (List.append_eq_nil.mp h).1
      rw [getLastD_indep _ hne _ e, ih x (by simp) (fun z hz => hg z (List.mem_cons_of_mem _ hz))]

theorem flatMap_head (l : List β) (g : β → List α) (d : β) (hl : l ≠ []) (hg : ∀ x ∈ l, g x ≠ []) (e : α) :
    (l.flatMap g).headD e = (g (l.headD d)).headD e := by
  cases l with
  | nil => exact absurd rfl hl
  | cons x xs => rw [List.flatMap_cons, headD_append _ _ _ (hg x (by simp))]; rfl

theorem perm_flatMap_congr (l : List β) (f g : β → List α) (h : ∀ x ∈ l, (f x).Perm (g x)) :
    (l.flatMap f).Perm (l.flatMap g) := by
  induction l with
  | nil => exact List.Perm.refl _
  | cons x xs ih =>
    simp only [List.flatMap_cons]
    exact List.Perm.append (h x (by simp)) (ih (fun y hy => h y (List.mem_cons_of_mem _ hy)))

theorem perm_flatMap_right {l l' : List β} (h : l.Perm l') (f : β → List α) : (l.flatMap f).Perm (l'.flatMap f) := by
  induction h with
  | nil => exact List.Perm.refl _
  | cons x _ ih => simp only [List.flatMap_cons]; exact List.Perm.append_left _ ih
  | swap x y l =>
    simp only [List.flatMap_cons, ← List.append_assoc]
    exact List.Perm.append_right _ List.perm_append_comm
  | trans _ _ ih1 ih2 => exact ih1.trans ih2

theorem flatMap_map' (l : List β) (p : β → Nat) (h : Nat → List α) : (l.map p).flatMap h = l.flatMap (fun x => h (p x)) := by
  induction l with
  | nil => rfl
  | cons x xs ih => simp only [List.map_cons, List.flatMap_cons, ih]

theorem mem_adjPairs_of {l : List β} {p : β × β} (h : p ∈ adjPairs l) : p.1 ∈ l ∧ p.2 ∈ l := by
  induction l with
  | nil => simp [adjPairs] at h
  | cons x xs ih =>
    cases xs with
    | nil => simp [adjPairs] at h
    | cons y ys =>
      simp only [adjPairs, List.mem_cons] at h
      rcases h with rfl | h
      · simp
      · have := ih h; exact ⟨List.mem_cons_of_mem _ this.1, List.mem_cons_of_mem _ this.2⟩
end lists

/-! ## Moving polygons and sharing edges -/

def pm (g : P → P) (e : P × P) : P × P := (g e.1, g e.2)

theorem edgesAux_map (g : P → P) (f x : P) (xs : List P) :
    (edgesAux f (x :: xs)).map (pm g) = edgesAux (g f) ((x :: xs).map g) := by
  induction xs generalizing x with
  | nil => rfl
  | cons y ys ih => simp only [edgesAux, List.map_cons, ih]; rfl

theorem edges_map (g : P → P) (t : Poly) : (edges t).map (pm g) = edges (t.map g) := by
  cases t with
  | nil => rfl
  | cons x xs => simp only [edges]; rw [edgesAux_map]; rfl

theorem shareEdge_map (g : P → P) (t u : Poly) (h : shareEdge t u = true) : shareEdge (t.map g) (u.map g) = true := by
  simp only [shareEdge, List.any_eq_true, Bool.or_eq_true, beq_iff_eq] at h ⊢
  obtain ⟨e, he, f, hf, hef⟩ := h
  refine ⟨pm g e, ?_, pm g f, ?_, ?_⟩
  · rw [← edges_map]; exact List.mem_map_of_mem _ he
  · rw [← edges_map]; exact List.mem_map_of_mem _ hf
  · rcases hef with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr rfl

theorem move_comp (A B : Aff P) (t : Poly) : move (A.comp B) t = move A (move B t) := by
  simp only [move, List.map_map]; congr 1; funext x; exact app_comp A B x

theorem move_inv (A : Aff P) (t : Poly) : move A (move A.inv t) = t := by
  simp only [move, List.map_map]
  conv => rhs; rw [← List.map_id t]
  congr 1; funext x; exact app_inv A x

theorem glue (A B : Aff P) (x y : Poly) (h : shareEdge x (move (A.inv.comp B) y) = true) :
    shareEdge (move A x) (move B y) = true := by
  have := shareEdge_map A.app _ _ h
  rwa [show (move (A.inv.comp B) y).map A.app = move B y by
    show move A (move (A.inv.comp B) y) = move B y
    rw [move_comp, move_inv]] at this

theorem move_congr {A B : Aff P} (h : ∀ x, A.app x = B.app x) (t : Poly) : move A t = move B t := by
  simp only [move]; congr 1; funext x; exact h x

/-! ## Walks -/

theorem walk_map (A : Aff P) (l : List Poly) (h : Walk l) : Walk (l.map (move A)) := by
  induction l with
  | nil => trivial
  | cons x xs ih =>
    cases xs with
    | nil => trivial
    | cons y ys => exact ⟨shareEdge_map _ _ _ h.1, ih h.2⟩

theorem walk_append (a b : List Poly) (ha : Walk a) (hb : Walk b)
    (hj : a ≠ [] → b ≠ [] → shareEdge (a.getLastD []) (b.headD []) = true) : Walk (a ++ b) := by
  induction a with
  | nil => exact hb
  | cons x a ih =>
    cases a with
    | nil =>
      cases b with
      | nil => trivial
      | cons y r => exact ⟨hj (by simp) (by simp), hb⟩
    | cons y r =>
      refine ⟨ha.1, ih ha.2 ?_⟩
      intro h1 h2; have := hj (by simp) h2; simpa [List.getLastD_cons] using this

theorem walk_flatMap (l : List (Nat × Nat)) (g : Nat × Nat → List Poly) (hne : ∀ x ∈ l, g x ≠ [])
    (hw : ∀ x ∈ l, Walk (g x))
    (hj : ∀ p ∈ adjPairs l, shareEdge ((g p.1).getLastD []) ((g p.2).headD []) = true) : Walk (l.flatMap g) := by
  induction l with
  | nil => trivial
  | cons x xs ih =>
    rw [List.flatMap_cons]
    apply walk_append _ _ (hw x (by simp))
    · apply ih (fun y hy => hne y (List.mem_cons_of_mem _ hy)) (fun y hy => hw y (List.mem_cons_of_mem _ hy))
      intro p hp; apply hj
      cases xs with
      | nil => simp [adjPairs] at hp
      | cons y ys => simp only [adjPairs]; exact List.mem_cons_of_mem _ hp
    · intro _ h2
      cases xs with
      | nil => simp at h2
      | cons y ys =>
        rw [flatMap_head _ _ y (by simp) (fun z hz => hne z (List.mem_cons_of_mem _ hz))]
        exact hj (x, y) (by simp [adjPairs])

/-! ## States -/

structure Good (s : Nat) : Prop where
  lt : s < RULE.length
  ne : (st s).prod ≠ []
  perm : ((st s).prod.map Prod.fst).Perm (kids (st s).shape)
  kid : ∀ cs ∈ (st s).prod, cs.2 < RULE.length ∧ (st cs.2).shape = kshape cs.1
  mys : (st s).shape = .D ∨ (st s).ein.b ≠ (st s).eout.b

theorem good {s : Nat} (h : s < RULE.length) : Good s := by
  have := checkRule_ok
  simp only [checkRule, List.all_eq_true, List.mem_range] at this
  have hs := this s h
  simp only [Bool.and_eq_true, bne_iff_ne, ne_eq, List.isPerm_iff, List.all_eq_true, decide_eq_true_eq,
    beq_iff_eq, Bool.or_eq_true] at hs
  exact ⟨h, hs.1.1.1, hs.1.1.2, hs.1.2, hs.2⟩

theorem path_succ (s n : Nat) :
    path s (n + 1) = (st s).prod.flatMap fun cs => (path cs.2 n).map (move (place n cs.1)) := rfl

theorem path_zero (s : Nat) : path s 0 =
    match (st s).shape with
    | .D => [spectre]
    | .G => [tile0 (st s).ein.b, tile0 (st s).eout.b] := rfl

theorem path_ne (n : Nat) : ∀ s, s < RULE.length → path s n ≠ [] := by
  induction n with
  | zero => intro s _; rw [path_zero]; split <;> simp
  | succ n ih =>
    intro s hs
    rw [path_succ]
    obtain ⟨cs, rest, hcs⟩ := List.exists_cons_of_ne_nil (good hs).ne
    rw [hcs, List.flatMap_cons]
    intro h
    have h1 := (List.append_eq_nil.mp h).1
    rw [List.map_eq_nil_iff] at h1
    exact ih cs.2 ((good hs).kid cs (by rw [hcs]; simp)).1 h1

/-! ## Junctions -/

/-- The last tile of route A's path and the first tile of route B's path, B placed by ρ, share an edge. -/
def J (j : Jn) (n : Nat) : Prop :=
  shareEdge ((path j.1 n).getLastD []) (move (evA (quad n) j.2.2) ((path j.2.1 n).headD [])) = true

theorem J_same {a b : Nat} {ρ ρ' : Aff Sym} (h : same ρ ρ' = true) (n : Nat) (hj : J (a, b, ρ') n) : J (a, b, ρ) n := by
  unfold J at hj ⊢
  rwa [move_congr (same_spec h n)]

theorem last_succ (s n : Nat) (hs : s < RULE.length) :
    (path s (n + 1)).getLastD [] =
      move (place n ((st s).prod.getLastD (0, 0)).1) ((path ((st s).prod.getLastD (0, 0)).2 n).getLastD []) := by
  have G := good hs
  have hmem := getLastD_mem _ G.ne (0, 0)
  rw [path_succ, flatMap_last _ _ (0, 0) G.ne]
  · have hne := path_ne n _ (G.kid _ hmem).1
    rw [getLastD_indep _ (by simpa using hne) [] (move (place n _) []), getLastD_map]
  · intro x hx; have := path_ne n _ (G.kid x hx).1; simpa using this

theorem head_succ (s n : Nat) (hs : s < RULE.length) :
    (path s (n + 1)).headD [] =
      move (place n ((st s).prod.headD (0, 0)).1) ((path ((st s).prod.headD (0, 0)).2 n).headD []) := by
  have G := good hs
  have hmem := headD_mem _ G.ne (0, 0)
  rw [path_succ, flatMap_head _ _ (0, 0) G.ne]
  · have hne := path_ne n _ (G.kid _ hmem).1
    obtain ⟨t, ts, ht⟩ := List.exists_cons_of_ne_nil hne
    rw [ht]; rfl
  · intro x hx; have := path_ne n _ (G.kid x hx).1; simpa using this

theorem evA_comp (q : Q4 P) (A B : Aff Sym) : evA q (A.comp B) = (evA q A).comp (evA q B) := (ev_hom q).comp A B
theorem evA_inv (q : Q4 P) (A : Aff Sym) : evA q A.inv = (evA q A).inv := (ev_hom q).inv A

theorem J_descend (j : Jn) (h1 : j.1 < RULE.length) (h2 : j.2.1 < RULE.length) (n : Nat) (h : J (descend j) n) :
    J j (n + 1) := by
  unfold J descend at *
  simp only at h
  rw [last_succ _ _ h1, head_succ _ _ h2]
  rw [evA_comp, evA_inv, evA_comp, evA_shift, ← place_eq, ← place_eq] at h
  have := glue _ _ _ _ h
  rwa [move_comp] at this

theorem J_all (n : Nat) : ∀ j ∈ CERT, J j n := by
  have hb := checkBase_ok
  simp only [checkBase, List.all_eq_true, Bool.and_eq_true, decide_eq_true_eq] at hb
  induction n with
  | zero => intro j hj; exact (hb j hj).2
  | succ n ih =>
    intro j hj
    have hc := checkClosed_ok
    simp only [checkClosed, List.all_eq_true] at hc
    have hm := hc j hj
    simp only [matchIn, List.any_eq_true, Bool.and_eq_true, beq_iff_eq] at hm
    obtain ⟨y, hy, ⟨e1, e2⟩, hs⟩ := hm
    apply J_descend j (hb j hj).1.1 (hb j hj).1.2
    have := ih y hy
    obtain ⟨y1, y2, yr⟩ := y
    simp only at e1 e2 hs
    subst e1 e2
    exact J_same hs n this

/-! ## The theorem -/

theorem walk_all (n : Nat) : ∀ s, s < RULE.length → Walk (path s n) := by
  have hm := checkMystic_ok
  simp only [checkMystic, Bool.and_eq_true] at hm
  induction n with
  | zero =>
    intro s hs
    rw [path_zero]
    have G := good hs
    split
    · trivial
    · next hG =>
      rcases G.mys with h | h
      · rw [h] at hG; cases hG
      · refine ⟨?_, trivial⟩
        cases hb : (st s).ein.b <;> cases hb' : (st s).eout.b <;> simp_all [tile0]
  | succ n ih =>
    intro s hs
    have G := good hs
    rw [path_succ]
    apply walk_flatMap
    · intro x hx; have := path_ne n _ (G.kid x hx).1; simpa using this
    · intro x hx; exact walk_map _ _ (ih _ (G.kid x hx).1)
    · intro p hp
      obtain ⟨⟨a, sa⟩, ⟨c, sb⟩⟩ := p
      have hmem := mem_adjPairs_of hp
      have ha := (G.kid _ hmem.1).1
      have hb := (G.kid _ hmem.2).1
      have hsib := checkSib_ok
      simp only [checkSib, List.all_eq_true, List.mem_range] at hsib
      have hx := hsib s hs (sa, sb, (TS a).inv.comp (TS c)) (by
        simp only [sibs, List.mem_map]; exact ⟨_, hp, rfl⟩)
      simp only [matchIn, List.any_eq_true, Bool.and_eq_true, beq_iff_eq] at hx
      obtain ⟨y, hy, ⟨e1, e2⟩, hsm⟩ := hx
      have hJ := J_all n y hy
      obtain ⟨y1, y2, yr⟩ := y
      simp only at e1 e2 hsm
      subst e1 e2
      have hJ' := J_same hsm n hJ
      unfold J at hJ'
      simp only at hJ'
      rw [evA_comp, evA_inv, ← place_eq, ← place_eq] at hJ'
      have := glue _ _ _ _ hJ'
      have hne1 := path_ne n _ ha
      have hne2 := path_ne n _ hb
      obtain ⟨t, ts, ht⟩ := List.exists_cons_of_ne_nil hne2
      simp only
      rw [getLastD_indep _ (by simpa using hne1) [] (move (place n a) []), getLastD_map, ht]
      rw [ht] at this
      exact this

theorem tiles_succ (X : Shape) (n : Nat) :
    tiles X (n + 1) = (kids X).flatMap fun j => (tiles (kshape j) n).map (move (place n j)) := by
  cases X <;> rfl

theorem perm_all (n : Nat) : ∀ s, s < RULE.length → (path s n).Perm (tiles (st s).shape n) := by
  induction n with
  | zero =>
    intro s hs
    have G := good hs
    rw [path_zero]
    split
    · next hD => rw [hD]; exact List.Perm.refl _
    · next hG =>
      rw [hG]
      rcases G.mys with h | h
      · rw [h] at hG; cases hG
      · cases hb : (st s).ein.b <;> cases hb' : (st s).eout.b <;> simp only [hb, hb', ne_eq, not_true_eq_false] at h <;>
          simp only [tile0, tiles, Bool.false_eq_true, ↓reduceIte]
        · exact List.Perm.refl _
        · exact List.Perm.swap _ _ _
  | succ n ih =>
    intro s hs
    have G := good hs
    rw [path_succ, tiles_succ]
    refine (perm_flatMap_congr _ _ (fun cs => (tiles (kshape cs.1) n).map (move (place n cs.1))) ?_).trans ?_
    · intro cs hcs
      have hk := G.kid cs hcs
      have := ih cs.2 hk.1
      rw [hk.2] at this
      exact this.map _
    · rw [← flatMap_map' _ Prod.fst (fun j => (tiles (kshape j) n).map (move (place n j)))]
      exact perm_flatMap_right G.perm _

/-! ## Entry and exit tiles -/

theorem tileAt_succ (X : Shape) (n : Nat) (a : Addr) :
    tileAt X (n + 1) a = move (place n a.head) (tileAt (kshape a.head) n a.tail) := by cases X <;> rfl

theorem head_ne7 (a : Addr) (h : no7 a = true) : a.head ≠ 7 := by
  obtain ⟨pre, per, b⟩ := a
  simp only [no7, List.all_eq_true, bne_iff_ne, ne_eq] at h
  cases pre with
  | cons x r => exact h x (by simp)
  | nil =>
    cases per with
    | nil => simp [Addr.head]
    | cons y ys => exact h y (by simp)

theorem no7_tail (a : Addr) (h : no7 a = true) : no7 a.tail = true := by
  obtain ⟨pre, per, b⟩ := a
  simp only [no7, List.all_eq_true, bne_iff_ne, ne_eq] at h ⊢
  cases pre with
  | cons x r =>
    intro y hy; apply h
    simp only [Addr.tail, List.mem_append, List.mem_cons] at hy ⊢
    rcases hy with hy | hy
    · exact Or.inl (Or.inr hy)
    · exact Or.inr hy
  | nil =>
    intro y hy; apply h
    simp only [Addr.tail, List.mem_append, List.nil_append] at hy ⊢
    rcases hy with hy | hy
    · exact List.mem_of_mem_drop hy
    · exact List.mem_of_mem_take hy

theorem head_tail_congr (a a' : Addr) (h1 : a.pre = a'.pre) (h2 : a.per = a'.per) :
    a.head = a'.head ∧ a.tail.pre = a'.tail.pre ∧ a.tail.per = a'.tail.per := by
  obtain ⟨pre, per, b⟩ := a
  obtain ⟨pre', per', b'⟩ := a'
  simp only at h1 h2; subst h1 h2
  cases pre <;> simp [Addr.head, Addr.tail]

theorem tileAt_agree (X : Shape) (a a' : Addr) (h : agree X a a' = true) (n : Nat) : tileAt X n a = tileAt X n a' := by
  simp only [agree, Bool.or_eq_true, beq_iff_eq, Bool.and_eq_true] at h
  rcases h with rfl | ⟨⟨⟨hpre, hper⟩, hX⟩, h7⟩
  · rfl
  · subst hX
    induction n generalizing a a' with
    | zero => rfl
    | succ n ih =>
      obtain ⟨hh, ht1, ht2⟩ := head_tail_congr a a' hpre hper
      have hk : kshape a'.head = .D := by
        rw [← hh]; simp only [kshape]; exact if_neg (head_ne7 a h7)
      rw [tileAt_succ, tileAt_succ, hh, hk, ih a.tail a'.tail (hpre := ht1) (hper := ht2) (h7 := no7_tail a h7)]

theorem addr_all (n : Nat) : ∀ s, s < RULE.length →
    (path s n).headD [] = tileAt (st s).shape n (st s).ein ∧
    (path s n).getLastD [] = tileAt (st s).shape n (st s).eout := by
  have hA := checkAddr_ok
  simp only [checkAddr, List.all_eq_true, List.mem_range] at hA
  induction n with
  | zero =>
    intro s _
    rw [path_zero]
    split
    · next hD => rw [hD]; exact ⟨rfl, rfl⟩
    · next hG => rw [hG]; exact ⟨rfl, rfl⟩
  | succ n ih =>
    intro s hs
    have G := good hs
    have h := hA s hs
    simp only [addrOK, Bool.and_eq_true, beq_iff_eq] at h
    have mf := headD_mem _ G.ne (0, 0)
    have ml := getLastD_mem _ G.ne (0, 0)
    constructor
    · rw [head_succ _ _ hs, tileAt_succ, (ih _ (G.kid _ mf).1).1, tileAt_agree _ _ _ h.1.2 n, (G.kid _ mf).2, h.1.1.1]
    · rw [last_succ _ _ hs, tileAt_succ, (ih _ (G.kid _ ml).1).2, tileAt_agree _ _ _ h.2 n, (G.kid _ ml).2, h.1.1.2]

/-- **Main theorem** (Theorem 3 of the paper). For every state s of the 32-state rule and every level n:
1. the path of s lists exactly the tiles of the level-n supertile of s's shape (each once, as a permutation);
2. consecutive tiles of the path share an edge;
2'. the path starts at the tile at s's entry address and ends at the tile at its exit address;
3. the path at level n+1 is the concatenation of its children's level-n paths, each moved by the placement of that
   child, and the supertile's tiles are the concatenation of the children's tiles moved by the same placements;
   so every sub-supertile is traversed as one contiguous run. -/
theorem spectre_hierarchical_paths (s : Nat) (hs : s < RULE.length) (n : Nat) :
    (path s n).Perm (tiles (st s).shape n) ∧ Walk (path s n) ∧
    (path s n).headD [] = tileAt (st s).shape n (st s).ein ∧
    (path s n).getLastD [] = tileAt (st s).shape n (st s).eout ∧
    path s (n + 1) = (st s).prod.flatMap (fun cs => (path cs.2 n).map (move (place n cs.1))) ∧
    tiles (st s).shape (n + 1) = (kids (st s).shape).flatMap (fun j => (tiles (kshape j) n).map (move (place n j))) :=
  ⟨perm_all n s hs, walk_all n s hs, (addr_all n s hs).1, (addr_all n s hs).2, path_succ s n, tiles_succ _ n⟩
