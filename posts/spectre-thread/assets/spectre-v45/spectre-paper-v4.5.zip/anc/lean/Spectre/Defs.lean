/-
  Definitions: the spectre, its substitution, and the paths of a rule.
  Everything a reader has to trust is in this file (and the rule data in Data.lean).

  Points of the plane with coordinates in Z[ζ₁₂]: a + b z + c z² + d z³, z = e^{iπ/6}.
  The substitution follows the reference construction of Smith, Myers, Kaplan and Goodman-Strauss
  (spectre.js, function buildSupertiles), with angles written in units of 30 degrees.
-/

/-- A point a + b z + c z² + d z³ with z = e^{iπ/6}. -/
@[ext] structure P where
  a : Int
  b : Int
  c : Int
  d : Int
deriving DecidableEq, Repr

/-- The operations the construction uses: addition, negation, zero, multiplication by z (rotation by 30
degrees) and the reflection x ↦ -conj(x) (the matrix [-1 0; 0 1] of spectre.js). The construction is written
once for any type with these operations, so that it can also be run on symbolic translations. -/
class ZOps (α : Type) where
  add : α → α → α
  neg : α → α
  zero : α
  zmul : α → α
  refl : α → α

open ZOps

/-- z⁴ = z² - 1, so z (a + bz + cz² + dz³) = -d + a z + (b + d) z² + c z³.
conj z = z - z³, conj z² = 1 - z², conj z³ = -z³, so -conj(a + bz + cz² + dz³) = (-a - c) - b z + c z² + (b + d) z³. -/
instance : ZOps P where
  add p q := ⟨p.a + q.a, p.b + q.b, p.c + q.c, p.d + q.d⟩
  neg p := ⟨-p.a, -p.b, -p.c, -p.d⟩
  zero := ⟨0, 0, 0, 0⟩
  zmul p := ⟨-p.d, p.a, p.b + p.d, p.c⟩
  refl p := ⟨-p.a - p.c, -p.b, p.c, p.b + p.d⟩

/-- Four things of one type (the four key points of a supertile). -/
@[ext] structure Q4 (α : Type) where
  p0 : α
  p1 : α
  p2 : α
  p3 : α
deriving DecidableEq, Repr

def Q4.get {α : Type} (q : Q4 α) : Fin 4 → α
  | 0 => q.p0
  | 1 => q.p1
  | 2 => q.p2
  | 3 => q.p3

def Q4.map {α β : Type} (f : α → β) (q : Q4 α) : Q4 β := ⟨f q.p0, f q.p1, f q.p2, f q.p3⟩

section generic
variable {α : Type} [ZOps α]

def sub (x y : α) : α := add x (neg y)

/-- Multiplication by z^n. -/
def zpow : Nat → α → α
  | 0, x => x
  | n + 1, x => zmul (zpow n x)

/-- The linear map x ↦ z^k R^r x, R the reflection. -/
def lin (k : Nat) (r : Bool) (x : α) : α := zpow (k % 12) (if r then refl x else x)

/-- An isometry x ↦ z^k R^r x + t (every transform of the construction has this form). -/
structure Aff (α : Type) where
  k : Nat
  r : Bool
  t : α

def Aff.app (A : Aff α) (x : α) : α := add (lin A.k A.r x) A.t

/-- Composition: (A.comp B).app = A.app ∘ B.app, using R z = z⁻¹ R. -/
def Aff.comp (A B : Aff α) : Aff α :=
  ⟨(A.k % 12 + (if A.r then 12 - B.k % 12 else B.k % 12)) % 12, xor A.r B.r, add A.t (lin A.k A.r B.t)⟩

def Aff.inv (A : Aff α) : Aff α :=
  let k := if A.r then A.k % 12 else (12 - A.k % 12) % 12
  ⟨k, A.r, neg (lin k A.r A.t)⟩

def Aff.id : Aff α := ⟨0, false, zero⟩
def Aff.trans (t : α) : Aff α := ⟨0, false, t⟩
/-- Rotation by k · 30 degrees. -/
def Aff.rot (k : Nat) : Aff α := ⟨k, false, zero⟩
def Aff.reflect : Aff α := ⟨0, true, zero⟩

/-- The transformation rules of spectre.js, [[60,3,1],[0,2,0],[60,3,1],[60,3,1],[0,2,0],[60,3,1],[-120,3,3]],
angles divided by 30. -/
def RULES : List (Int × Fin 4 × Fin 4) := [(2, 3, 1), (0, 2, 0), (2, 3, 1), (2, 3, 1), (0, 2, 0), (2, 3, 1), (-4, 3, 3)]

/-- One step of the loop in buildSupertiles: accumulate the angle, rotate, and translate so that the rotated key
point `to` lands on the previous child's key point `from`. -/
def buildStep (quad : Q4 α) : List (Aff α) × Int → Int × Fin 4 × Fin 4 → List (Aff α) × Int
  | (Ts, total), (ang, frm, to) =>
    let total := total + ang
    let R : Aff α := Aff.rot (total % 12).toNat
    let src := (Ts.getLastD Aff.id).app (quad.get frm)
    (Ts ++ [Aff.comp (Aff.trans (sub src (R.app (quad.get to)))) R], total)

/-- The placements of the 8 children of a supertile whose children have key points `quad`
(spectre.js: Ts, then Ts[idx] = R · Ts[idx]). -/
def placements (quad : Q4 α) : List (Aff α) :=
  ((RULES.foldl (buildStep quad) ([Aff.id], 0)).1).map (Aff.comp Aff.reflect)

/-- The key points of the supertile (spectre.js: super_quad). -/
def superQuad (quad : Q4 α) : Q4 α :=
  let Ts := placements quad
  ⟨(Ts.getD 6 Aff.id).app quad.p2, (Ts.getD 5 Aff.id).app quad.p1,
   (Ts.getD 3 Aff.id).app quad.p2, (Ts.getD 0 Aff.id).app quad.p1⟩

end generic

/-! ## The spectre -/

def unitDir (h : Nat) : P := zpow h ⟨1, 0, 0, 0⟩

/-- Directions of the 14 unit edges, in units of 30 degrees. -/
def HEAD : List Nat := [0, 10, 1, 3, 0, 2, 5, 7, 4, 6, 6, 8, 11, 9]

def walkFrom : List Nat → P → List P
  | [], _ => []
  | h :: hs, p => p :: walkFrom hs (add p (unitDir h))

/-- The 14 vertices of the straight-edged spectre Tile(1,1). -/
def spectre : List P := walkFrom HEAD zero

def sp (i : Nat) : P := spectre.getD i zero

/-- Key points of a single spectre: vertices 3, 5, 7, 11 (spectre.js buildSpectreBase). -/
def quad0 : Q4 P := ⟨sp 3, sp 5, sp 7, sp 11⟩

/-- The second spectre of the mystic: translate to vertex 8 after rotating by 30 degrees. -/
def mystic : Aff P := Aff.comp (Aff.trans (sp 8)) (Aff.rot 1)

/-! ## Supertiles -/

inductive Shape
  | D   -- every label except Gamma: 8 children
  | G   -- Gamma, the mystic: child 2 is absent
deriving DecidableEq, Repr

def kids : Shape → List Nat
  | .D => [0, 1, 2, 3, 4, 5, 6, 7]
  | .G => [0, 1, 3, 4, 5, 6, 7]

/-- Child 7 is always a Gamma; every other child has 8 children of its own. -/
def kshape (j : Nat) : Shape := if j = 7 then .G else .D

/-- Key points of a level-n supertile. -/
def quad : Nat → Q4 P
  | 0 => quad0
  | n + 1 => superQuad (quad n)

/-- Placement of child j (a level-n supertile) inside a level-(n+1) supertile. -/
def place (n j : Nat) : Aff P := (placements (quad n)).getD j Aff.id

abbrev Poly := List P

def move (A : Aff P) (t : Poly) : Poly := t.map A.app

/-- The tiles of the level-n supertile of shape X, children in index order. -/
def tiles : Shape → Nat → List Poly
  | .D, 0 => [spectre]
  | .G, 0 => [spectre, move mystic spectre]
  | X, n + 1 => (kids X).flatMap fun j => (tiles (kshape j) n).map (move (place n j))

/-! ## Addresses -/

def tile0 (b : Bool) : Poly := if b then move mystic spectre else spectre

/-- An eventually periodic word of child indices, pre(per), read from the top level down; b picks the second
spectre of a level-0 mystic. -/
structure Addr where
  pre : List Nat
  per : List Nat
  b : Bool
deriving DecidableEq, Repr

def Addr.head (a : Addr) : Nat :=
  match a.pre with
  | x :: _ => x
  | [] => a.per.headD 0

def Addr.tail (a : Addr) : Addr :=
  match a.pre with
  | _ :: r => ⟨r, a.per, a.b⟩
  | [] => ⟨[], a.per.drop 1 ++ a.per.take 1, a.b⟩

/-- The tile at address a in the level-n supertile of shape X: follow the first n letters. -/
def tileAt : Shape → Nat → Addr → Poly
  | .D, 0, _ => spectre
  | .G, 0, a => tile0 a.b
  | _, n + 1, a => move (place n a.head) (tileAt (kshape a.head) n a.tail)

/-! ## Rules and paths -/

/-- A state of a rule: its shape, entry and exit addresses, and its production: the children in visiting order,
each with the state used inside it. -/
structure St where
  shape : Shape
  ein : Addr
  eout : Addr
  prod : List (Nat × Nat)

/-- The path of a state at level n, as the list of tiles in visiting order. At level 0 it is a single spectre,
or the two spectres of a mystic. Above that it is the concatenation of the children's paths, each moved into place:
so every sub-supertile is traversed as one contiguous run. -/
def pathOf (R : List St) : Nat → Nat → List Poly
  | s, 0 =>
    match (R.getD s ⟨.D, ⟨[], [], false⟩, ⟨[], [], false⟩, []⟩).shape with
    | .D => [spectre]
    | .G => [tile0 (R.getD s ⟨.D, ⟨[], [], false⟩, ⟨[], [], false⟩, []⟩).ein.b,
             tile0 (R.getD s ⟨.D, ⟨[], [], false⟩, ⟨[], [], false⟩, []⟩).eout.b]
  | s, n + 1 => (R.getD s ⟨.D, ⟨[], [], false⟩, ⟨[], [], false⟩, []⟩).prod.flatMap fun cs => (pathOf R cs.2 n).map (move (place n cs.1))

/-! ## Sharing an edge -/

def edgesAux (first : P) : List P → List (P × P)
  | [] => []
  | [x] => [(x, first)]
  | x :: y :: r => (x, y) :: edgesAux first (y :: r)

def edges : Poly → List (P × P)
  | [] => []
  | x :: r => edgesAux x (x :: r)

/-- Two polygons share an edge: some edge of one has the same two end points as some edge of the other. -/
def shareEdge (t u : Poly) : Bool :=
  (edges t).any fun e => (edges u).any fun f => e == f || e == (f.2, f.1)

/-- Consecutive tiles share an edge. -/
def Walk : List Poly → Prop
  | x :: y :: r => shareEdge x y = true ∧ Walk (y :: r)
  | _ => True
