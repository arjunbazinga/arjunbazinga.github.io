/- The construction commutes with any map that preserves the operations. -/
import Spectre.Alg
open ZOps
set_option linter.unusedSectionVars false

structure IsHom {α β : Type} [ZOps α] [ZOps β] (f : α → β) : Prop where
  add : ∀ x y, f (add x y) = add (f x) (f y)
  neg : ∀ x, f (neg x) = neg (f x)
  zero : f zero = zero
  zmul : ∀ x, f (zmul x) = zmul (f x)
  refl : ∀ x, f (refl x) = refl (f x)

theorem getLastD_map {α β : Type} (g : α → β) (l : List α) (d : α) : (l.map g).getLastD (g d) = g (l.getLastD d) := by
  induction l generalizing d with
  | nil => rfl
  | cons x xs ih => simp only [List.map_cons, List.getLastD_cons, ih]

theorem getD_map {α β : Type} (g : α → β) (l : List α) (i : Nat) (d : α) : (l.map g).getD i (g d) = g (l.getD i d) := by
  induction l generalizing i with
  | nil => simp
  | cons x xs ih => cases i <;> simp [ih]

namespace IsHom
variable {α β : Type} [ZOps α] [ZOps β] {f : α → β} (h : IsHom f)
include h

theorem zpow (n : Nat) (x : α) : f (zpow n x) = zpow n (f x) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [zpow_succ, zpow_succ, h.zmul, ih]

theorem lin (k : Nat) (r : Bool) (x : α) : f (lin k r x) = lin k r (f x) := by
  cases r <;> simp only [_root_.lin, Bool.false_eq_true, ↓reduceIte, h.zpow, h.refl]

theorem sub (x y : α) : f (sub x y) = sub (f x) (f y) := by simp only [_root_.sub, h.add, h.neg]

theorem app (A : Aff α) (x : α) : f (A.app x) = (A.map f).app (f x) := by
  simp only [Aff.app, Aff.map, h.add, h.lin]

theorem comp (A B : Aff α) : (A.comp B).map f = (A.map f).comp (B.map f) := by
  simp only [Aff.comp, Aff.map, h.add, h.lin]

theorem inv (A : Aff α) : A.inv.map f = (A.map f).inv := by
  simp only [Aff.inv, Aff.map, h.neg, h.lin]

theorem id' : (Aff.id : Aff α).map f = Aff.id := by simp only [Aff.id, Aff.map, h.zero]
theorem trans (t : α) : (Aff.trans t).map f = Aff.trans (f t) := rfl
theorem rot (k : Nat) : (Aff.rot k : Aff α).map f = Aff.rot k := by simp only [Aff.rot, Aff.map, h.zero]
theorem reflect : (Aff.reflect : Aff α).map f = Aff.reflect := by simp only [Aff.reflect, Aff.map, h.zero]

theorem get (q : Q4 α) (i : Fin 4) : (q.map f).get i = f (q.get i) := by
  match i with
  | 0 => rfl
  | 1 => rfl
  | 2 => rfl
  | 3 => rfl

theorem buildStep (q : Q4 α) (Ts : List (Aff α)) (tot : Int) (rl : Int × Fin 4 × Fin 4) :
    _root_.buildStep (q.map f) (Ts.map (Aff.map f), tot) rl =
      ((_root_.buildStep q (Ts, tot) rl).1.map (Aff.map f), (_root_.buildStep q (Ts, tot) rl).2) := by
  obtain ⟨ang, frm, to⟩ := rl
  simp only [_root_.buildStep, List.map_append, List.map_cons, List.map_nil, h.comp, h.trans, h.rot, h.sub, h.app, h.get]
  rw [← h.id', getLastD_map]

theorem foldl (q : Q4 α) (l : List (Int × Fin 4 × Fin 4)) (Ts : List (Aff α)) (tot : Int) :
    l.foldl (_root_.buildStep (q.map f)) (Ts.map (Aff.map f), tot) =
      ((l.foldl (_root_.buildStep q) (Ts, tot)).1.map (Aff.map f), (l.foldl (_root_.buildStep q) (Ts, tot)).2) := by
  induction l generalizing Ts tot with
  | nil => rfl
  | cons rl l ih => simp only [List.foldl_cons, h.buildStep]; exact ih _ _

theorem placements (q : Q4 α) : _root_.placements (q.map f) = (_root_.placements q).map (Aff.map f) := by
  have := h.foldl q RULES [Aff.id] 0
  simp only [List.map_cons, List.map_nil, h.id'] at this
  simp only [_root_.placements, this, List.map_map]
  congr 1; funext A; simp only [Function.comp, h.comp, h.reflect]

theorem superQuad (q : Q4 α) : _root_.superQuad (q.map f) = (_root_.superQuad q).map f := by
  simp only [_root_.superQuad, h.placements]
  rw [← h.id', getD_map, getD_map, getD_map, getD_map]
  simp only [Q4.map, h.app]
end IsHom
