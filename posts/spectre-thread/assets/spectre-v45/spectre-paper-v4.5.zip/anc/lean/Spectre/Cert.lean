/-
  The finite checks, evaluated by the kernel. Translations are handled symbolically: a placement inside a
  level-(n+1) supertile has translation `ev (quad n) K` for a fixed `K : Sym`.
-/
import Spectre.Data
open ZOps

instance {α : Type} [ZOps α] : ZOps (Q4 α) where
  add x y := ⟨add x.p0 y.p0, add x.p1 y.p1, add x.p2 y.p2, add x.p3 y.p3⟩
  neg x := x.map neg
  zero := ⟨zero, zero, zero, zero⟩
  zmul x := x.map zmul
  refl x := x.map refl

def P.smul (n : Int) (p : P) : P := ⟨n * p.a, n * p.b, n * p.c, n * p.d⟩

/-- The linear map with columns L applied to p. -/
def linApp (L : Q4 P) (p : P) : P :=
  add (add (add (P.smul p.a L.p0) (P.smul p.b L.p1)) (P.smul p.c L.p2)) (P.smul p.d L.p3)

/-- Evaluate a symbolic translation at concrete key points. -/
def ev (q : Q4 P) (K : Sym) : P :=
  add (add (add (linApp K.p0 q.p0) (linApp K.p1 q.p1)) (linApp K.p2 q.p2)) (linApp K.p3 q.p3)

def E4 : Q4 P := ⟨⟨1, 0, 0, 0⟩, ⟨0, 1, 0, 0⟩, ⟨0, 0, 1, 0⟩, ⟨0, 0, 0, 1⟩⟩
def Z4 : Q4 P := ⟨zero, zero, zero, zero⟩
/-- The key points themselves, as symbolic values. -/
def QSYM : Q4 Sym := ⟨⟨E4, Z4, Z4, Z4⟩, ⟨Z4, E4, Z4, Z4⟩, ⟨Z4, Z4, E4, Z4⟩, ⟨Z4, Z4, Z4, E4⟩⟩

def Aff.map {α β : Type} (f : α → β) (A : Aff α) : Aff β := ⟨A.k, A.r, f A.t⟩
def evA (q : Q4 P) (A : Aff Sym) : Aff P := A.map (ev q)

/-- Symbolic placements of the children. -/
def TS (j : Nat) : Aff Sym := (placements QSYM).getD j Aff.id
def SQ : Q4 Sym := superQuad QSYM

def compL (L : Q4 P) (S : Sym) : Sym := S.map (Q4.map (linApp L))
/-- K ↦ K ∘ (the map from a supertile's key points to its parent's). -/
def shiftM (K : Sym) : Sym :=
  add (add (add (compL K.p0 SQ.p0) (compL K.p1 SQ.p1)) (compL K.p2 SQ.p2)) (compL K.p3 SQ.p3)
def shiftA (A : Aff Sym) : Aff Sym := ⟨A.k, A.r, shiftM A.t⟩

/-- Two symbolic isometries agree at levels 0..5 (hence, by the recurrence, at every level). -/
def same (A B : Aff Sym) : Bool :=
  A.k % 12 == B.k % 12 && A.r == B.r &&
  [0, 1, 2, 3, 4, 5].all fun m => ev (quad m) A.t == ev (quad m) B.t

def st (s : Nat) : St := RULE.getD s ⟨.D, ⟨[], [], false⟩, ⟨[], [], false⟩, []⟩
abbrev path := pathOf RULE

abbrev Jn := Nat × Nat × Aff Sym

def descend (j : Jn) : Jn :=
  let ac := (st j.1).prod.getLastD (0, 0)
  let cb := (st j.2.1).prod.headD (0, 0)
  (ac.2, cb.2, (TS ac.1).inv.comp ((shiftA j.2.2).comp (TS cb.1)))

def matchIn (x : Jn) : Bool := CERT.any fun y => y.1 == x.1 && y.2.1 == x.2.1 && same x.2.2 y.2.2

def adjPairs {β : Type} : List β → List (β × β)
  | x :: y :: r => (x, y) :: adjPairs (y :: r)
  | _ => []

def sibs (s : Nat) : List Jn :=
  (adjPairs (st s).prod).map fun ((a, sa), (c, sb)) => (sa, sb, (TS a).inv.comp (TS c))

def checkClosed : Bool := CERT.all fun j => matchIn (descend j)
def checkSib : Bool := (List.range RULE.length).all fun s => (sibs s).all matchIn
def checkBase : Bool := CERT.all fun j =>
  j.1 < RULE.length && j.2.1 < RULE.length &&
  shareEdge ((path j.1 0).getLastD []) (move (evA (quad 0) j.2.2) ((path j.2.1 0).headD []))
def checkRule : Bool := (List.range RULE.length).all fun s =>
  (st s).prod != [] && ((st s).prod.map Prod.fst).isPerm (kids (st s).shape) &&
  (st s).prod.all (fun cs => cs.2 < RULE.length && (st cs.2).shape == kshape cs.1) &&
  ((st s).shape == .D || (st s).ein.b != (st s).eout.b)
def checkMystic : Bool :=
  shareEdge spectre (move mystic spectre) && shareEdge (move mystic spectre) spectre

/-- No letter 7: the address never enters a mystic below the top, so b is irrelevant in a supertile of shape D. -/
def no7 (a : Addr) : Bool := (a.pre ++ a.per).all (· != 7)
/-- Two addresses name the same tile in every supertile of shape X. -/
def agree (X : Shape) (a a' : Addr) : Bool := a == a' || (a.pre == a'.pre && a.per == a'.per && X == .D && no7 a)
def addrOK (s : Nat) : Bool :=
  let f := (st s).prod.headD (0, 0)
  let l := (st s).prod.getLastD (0, 0)
  f.1 == (st s).ein.head && l.1 == (st s).eout.head &&
  agree (st f.2).shape (st f.2).ein (st s).ein.tail && agree (st l.2).shape (st l.2).eout (st s).eout.tail
def checkAddr : Bool := (List.range RULE.length).all addrOK
