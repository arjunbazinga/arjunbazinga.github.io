/- Algebra of points and isometries. -/
import Spectre.Cert
open ZOps

macro "ring'" : tactic => `(tactic| ((try simp only [Int.mul_add, Int.add_mul, Int.mul_sub, Int.sub_mul, Int.mul_neg,
  Int.neg_mul, Int.mul_assoc, Int.mul_comm, Int.mul_left_comm, Int.sub_eq_add_neg, Int.neg_add, Int.neg_neg]) <;> (try omega)))

@[simp] theorem P_add (p q : P) : (add p q : P) = ⟨p.a + q.a, p.b + q.b, p.c + q.c, p.d + q.d⟩ := rfl
@[simp] theorem P_neg (p : P) : (neg p : P) = ⟨-p.a, -p.b, -p.c, -p.d⟩ := rfl
@[simp] theorem P_zero : (zero : P) = ⟨0, 0, 0, 0⟩ := rfl
@[simp] theorem P_zmul (p : P) : (zmul p : P) = ⟨-p.d, p.a, p.b + p.d, p.c⟩ := rfl
@[simp] theorem P_refl (p : P) : (refl p : P) = ⟨-p.a - p.c, -p.b, p.c, p.b + p.d⟩ := rfl

section generic
variable {α : Type} [ZOps α]
theorem zpow_zero (x : α) : zpow 0 x = x := rfl
theorem zpow_succ (n : Nat) (x : α) : zpow (n + 1) x = zmul (zpow n x) := rfl
theorem zpow_add (a b : Nat) (x : α) : zpow a (zpow b x) = zpow (a + b) x := by
  induction a with
  | zero => simp [zpow_zero]
  | succ n ih => rw [zpow_succ, ih, Nat.add_right_comm]; rfl
end generic

theorem zpow12 (p : P) : zpow 12 p = p := by
  simp only [zpow_succ, zpow_zero, P_zmul]; ext <;> simp <;> omega

theorem zpow_mul12 (m : Nat) (p : P) : zpow (12 * m) p = p := by
  induction m with
  | zero => rfl
  | succ m ih => rw [Nat.mul_succ, ← zpow_add, zpow12, ih]

theorem zpow_mod (n : Nat) (p : P) : zpow n p = zpow (n % 12) p := by
  conv => lhs; rw [← Nat.mod_add_div n 12]
  rw [← zpow_add, zpow_mul12]

theorem zpow_congr {a b : Nat} (h : a % 12 = b % 12) (p : P) : zpow a p = zpow b p := by
  rw [zpow_mod a, zpow_mod b, h]

theorem zmul_add (p q : P) : zmul (add p q) = add (zmul p) (zmul q) := by ext <;> simp <;> omega
theorem refl_add (p q : P) : refl (add p q) = add (refl p) (refl q) := by ext <;> simp <;> omega
theorem zmul_neg (p : P) : zmul (neg p) = neg (zmul p) := by ext <;> simp <;> omega
theorem refl_neg (p : P) : refl (neg p) = neg (refl p) := by ext <;> simp <;> omega
theorem refl_refl (p : P) : refl (refl p) = p := by ext <;> simp <;> omega
theorem refl_zmul (p : P) : refl (zmul p) = zpow 11 (refl p) := by
  simp only [zpow_succ, zpow_zero, P_zmul, P_refl]; ext <;> simp <;> omega

theorem zpow_addP (n : Nat) (p q : P) : zpow n (add p q) = add (zpow n p) (zpow n q) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [zpow_succ, zpow_succ, zpow_succ, ih, zmul_add]
theorem zpow_negP (n : Nat) (p : P) : zpow n (neg p) = neg (zpow n p) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [zpow_succ, zpow_succ, ih, zmul_neg]
theorem refl_zpow (n : Nat) (p : P) : refl (zpow n p) = zpow (11 * n) (refl p) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [zpow_succ, refl_zmul, ih, zpow_add]; congr 1; omega

theorem lin_add (k : Nat) (r : Bool) (p q : P) : lin k r (add p q) = add (lin k r p) (lin k r q) := by
  cases r <;> simp only [lin, Bool.false_eq_true, ↓reduceIte, refl_add, zpow_addP]
theorem lin_neg (k : Nat) (r : Bool) (p : P) : lin k r (neg p) = neg (lin k r p) := by
  cases r <;> simp only [lin, Bool.false_eq_true, ↓reduceIte, refl_neg, zpow_negP]

theorem lin_lin (k1 k2 : Nat) (r1 r2 : Bool) (x : P) :
    lin k1 r1 (lin k2 r2 x) = lin ((k1 % 12 + (if r1 then 12 - k2 % 12 else k2 % 12)) % 12) (xor r1 r2) x := by
  cases r1 <;> cases r2 <;>
    simp only [lin, Bool.false_eq_true, ↓reduceIte, Bool.xor_false, Bool.xor_true, Bool.not_false, Bool.not_true,
      refl_zpow, refl_refl, zpow_add] <;> apply zpow_congr <;> omega

theorem app_comp (A B : Aff P) (x : P) : (A.comp B).app x = A.app (B.app x) := by
  simp only [Aff.app, Aff.comp, lin_add, lin_lin]
  ext <;> simp <;> omega

theorem app_inv (A : Aff P) (y : P) : A.app (A.inv.app y) = y := by
  simp only [Aff.app, Aff.inv, lin_add, lin_neg, lin_lin, Bool.xor_self]
  have h : ∀ x : P, lin ((A.k % 12 + (if A.r then 12 - (if A.r then A.k % 12 else (12 - A.k % 12) % 12) % 12
      else (if A.r then A.k % 12 else (12 - A.k % 12) % 12) % 12)) % 12) false x = x := by
    intro x; simp only [lin, Bool.false_eq_true, ↓reduceIte]
    rw [zpow_congr (b := 0)]; · rfl
    cases A.r <;> simp <;> omega
  rw [h, h]; ext <;> simp <;> omega
