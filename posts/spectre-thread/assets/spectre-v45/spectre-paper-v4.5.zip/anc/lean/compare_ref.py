"""Compare the tiles built by Spectre/Defs.lean with a transcription of the authors' spectre.js (from 39_reference_check.py)."""
import math, sys
src = open(sys.argv[1]).read(); src = src[:src.index('# ---------------- ours')]
g = {}; exec(src, g); REF = g['REF']; ident = g['ident']
S3 = math.sqrt(3)
def xy(a, b, c, d): return (a + b * S3 / 2 + c / 2, b / 2 + c * S3 / 2 + d)
L = {}
for line in open('lean_tiles.txt'):
    X, n, body = line.split(' ', 2); L.setdefault((X, int(n)), []).append([xy(*map(int, p.split())) for p in body.strip().split(';')])
worst = 0
for (X, n), tl in sorted(L.items()):
    R = REF[n]['Delta' if X == 'D' else 'Gamma'].polys(ident)
    assert len(R) == len(tl), (X, n, len(R), len(tl))
    d = max(abs(a - b) for P, Q in zip(R, tl) for p, q in zip(P, Q) for a, b in zip(p, q)); worst = max(worst, d)
    print(f'{X} level {n}: {len(tl)} tiles, same order, largest vertex difference {d:.1e}')
print('largest difference overall', f'{worst:.1e}')
