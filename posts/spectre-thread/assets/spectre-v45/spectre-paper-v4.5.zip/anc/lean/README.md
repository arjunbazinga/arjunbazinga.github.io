# Lean 4 proof of the main theorem (32-state rule)

`spectre_hierarchical_paths` in `Spectre/Main.lean` is Theorem 3 of the paper. For every state s of the 32-state
rule and every level n,
1. the path of s lists the tiles of the level-n supertile, each once (a permutation of the tile list);
2. consecutive tiles share an edge;
3. the path starts at the tile at s's entry address and ends at the tile at its exit address;
4. the path at level n+1 is its children's level-n paths, each moved into place, concatenated. The tiles are
   the children's tiles moved by the same placements, so every sub-supertile is one contiguous run.

The theorem depends only on Lean's standard axioms (`propext`, `Classical.choice`, `Quot.sound`). The proof uses no
`sorry` and no `native_decide`: the finite checks are evaluated by the kernel. It uses the core library only (no
Mathlib).

## Build

    lake build                  # about 75 s; Lean 4.15.0 (see lean-toolchain)
    lake env lean Check.lean    # prints the axioms

## What to read (the trusted part)

- `Spectre/Defs.lean`:
  - points of Z[zeta_12];
  - addresses and `tileAt`, the tile at an address;
  - the spectre;
  - the substitution, written to follow `spectre.js`;
  - `tiles`, `pathOf`, `shareEdge` and `Walk`.
- `Spectre/Data.lean`, `RULE`: the rule as data.

Everything else is checked by Lean, including `CERT`, which is untrusted data.

## How the proof goes

- **Junctions.** A junction is named by the two routes it joins plus a relative position, so the induction starts
  at single tiles. There are 74 junctions, closed under descent, each checked on two spectres. The 214 sibling
  junctions are matched to them.
- **Translations.** These are symbolic: linear in the parent's key points (`Sym`).
- **Six levels suffice.** Two symbolic translations that agree at six consecutive levels agree at all levels. This
  follows from v_{n+6} = 9 v_{n+4} - 9 v_{n+2} + v_n, proved from its case n = 0 and the linearity of the
  construction.
- **Naturality.** The construction is written once over any type with the operations it uses. A map preserving
  those operations commutes with it, which relates concrete placements to symbolic ones.

## Cross-checks

- `lake env lean Export.lean > lean_tiles.txt; python3 compare_ref.py ../39_reference_check.py` compares Lean's tiles with
  the transcription of `spectre.js`. They agree vertex for vertex at levels 0 to 4 (largest difference 8.5e-14,
  floating-point rounding).
- `python3 gen_cert.py ../results/rule_Bsym.json` regenerates `Spectre/Data.lean`.

## Not covered

- the 30-state rule;
- the whole-plane theorem;
- locality;
- the drawn line;
- the limit curve.
