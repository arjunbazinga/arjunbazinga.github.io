import Spectre.Main
#print axioms spectre_hierarchical_paths
