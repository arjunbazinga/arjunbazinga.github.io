"""The certificate of Theorem 3 in the form the paper and the Lean proof use: junctions named by routes.

A mirror of lean/Spectre/Defs.lean in exact integer arithmetic (also used, with Lean output, as lean/gen_cert.py).

Points: Z^4, a + b z + c z^2 + d z^3, z = e^(i pi/6). Isometries: (k, r, t), x -> z^k R^r x + t, R(x) = -conj(x).
The substitution follows spectre.js. Translations are tracked symbolically as linear functions of the parent's key
points (16 integers): a symbolic vector is a 16 x 4 integer matrix (row = basis direction of the key points).
A junction is (route A, route B, relative position rho): the last tile of A's path and the first tile of B's path,
B placed by rho(n), share an edge at level n. Descent replaces A by its last child, B by its first child.
Keys: rho evaluated at levels 0..5 (enough, by the recurrence v_{n+6} = 9 v_{n+4} - 9 v_{n+2} + v_n).
usage: python3 43_route_certificate.py results/rule_Bsym.json"""
import sys, json
import numpy as np
def zmul(p): a, b, c, d = p; return (-d, a, b + d, c)
def refl(p): a, b, c, d = p; return (-a - c, -b, c, b + d)
def add(p, q): return tuple(x + y for x, y in zip(p, q))
def neg(p): return tuple(-x for x in p)
def sub(p, q): return add(p, neg(q))
ZERO = (0, 0, 0, 0)
# symbolic: 16 x 4 int arrays; ops act on every row
S_zmul = lambda K: np.array([zmul(tuple(r)) for r in K], dtype=object)
S_refl = lambda K: np.array([refl(tuple(r)) for r in K], dtype=object)
class Ops:
    def __init__(s, add, neg, zero, zm, rf): s.add, s.neg, s.zero, s.zmul, s.refl = add, neg, zero, zm, rf
    def sub(s, a, b): return s.add(a, s.neg(b))
PO = Ops(add, neg, ZERO, zmul, refl)
SO = Ops(lambda a, b: a + b, lambda a: -a, np.zeros((16, 4), dtype=object), S_zmul, S_refl)
def lin(O, k, r, x):
    if r: x = O.refl(x)
    for _ in range(k % 12): x = O.zmul(x)
    return x
def app(O, A, x): k, r, t = A; return O.add(lin(O, k, r, x), t)
def comp(O, A, B): k1, r1, t1 = A; k2, r2, t2 = B; return ((k1 + (-k2 if r1 else k2)) % 12, r1 ^ r2, O.add(t1, lin(O, k1, r1, t2)))
def inv(O, A): k, r, t = A; k2 = k % 12 if r else (-k) % 12; return (k2, r, O.neg(lin(O, k2, r, t)))
def ident(O): return (0, False, O.zero)
def trans(O, t): return (0, False, t)
def rot(O, deg): return ((deg // 30) % 12, False, O.zero)
REFLECT = lambda O: (0, True, O.zero)
RULES = [(60, 3, 1), (0, 2, 0), (60, 3, 1), (60, 3, 1), (0, 2, 0), (60, 3, 1), (-120, 3, 3)]
def build(O, quad):
    Ts = [ident(O)]; total = 0
    for ang, frm, to in RULES:
        total += ang; R = rot(O, total); tq = [app(O, R, p) for p in quad]
        src = app(O, Ts[-1], quad[frm]); Ts.append(comp(O, trans(O, O.sub(src, tq[to])), R))
    Ts = [comp(O, REFLECT(O), T) for T in Ts]
    return Ts, [app(O, Ts[6], quad[2]), app(O, Ts[5], quad[1]), app(O, Ts[3], quad[2]), app(O, Ts[0], quad[1])]
# spectre
def zpow(k):
    p = (1, 0, 0, 0)
    for _ in range(k % 12): p = zmul(p)
    return p
HEAD = [0, 300, 30, 90, 0, 60, 150, 210, 120, 180, 180, 240, 330, 270]
SP = [ZERO]
for h in HEAD[:-1]: SP.append(add(SP[-1], zpow(h // 30)))
assert add(SP[-1], zpow(HEAD[-1] // 30)) == ZERO
QUAD0 = [SP[3], SP[5], SP[7], SP[11]]
MYSTIC = comp(PO, trans(PO, SP[8]), rot(PO, 30))
def ev(q, K): v = [x for p in q for x in p]; return tuple(sum(v[i] * K[i][j] for i in range(16)) for j in range(4))
QSYM = [np.array([[int(i == 4 * a + j) for j in range(4)] for i in range(16)], dtype=object) for a in range(4)]
TSYM, SQSYM = build(SO, QSYM)
V = [QUAD0]
for _ in range(12): V.append(build(PO, V[-1])[1])
for n in range(8):                        # naturality, numerically
    Tn, qn = build(PO, V[n])
    assert all(Tn[j] == (TSYM[j][0], TSYM[j][1], ev(V[n], TSYM[j][2])) for j in range(8)) and qn == [ev(V[n], K) for K in SQSYM]
flat = lambda q: [x for p in q for x in p]
assert all(a - 9 * b + 9 * c - d == 0 for a, b, c, d in zip(flat(V[6]), flat(V[4]), flat(V[2]), flat(V[0])))
# M as symbolic: column (i, c) -> ev of unit quad
UNIT = [[tuple(int(4 * a + j == i) for j in range(4)) for a in range(4)] for i in range(16)]
MFUN = [build(PO, UNIT[i])[1] for i in range(16)]           # Mfun(unit_i)
def shiftM(K): return np.array([ev(MFUN[i], K) for i in range(16)], dtype=object)
for n in range(5):
    K = TSYM[3][2]; assert ev(V[n + 1], K) == ev(V[n], shiftM(K))
# tiles at level 0
def tile0(X, b): return SP if (X == 'D' or not b) else [app(PO, MYSTIC, p) for p in SP]
def edges(t): return {frozenset((t[i], t[(i + 1) % 14])) for i in range(14)}
def share(t, u): return bool(edges(t) & edges(u))
# rule
d = json.load(open(sys.argv[1]))
def ploc(t):
    g = t.endswith('b'); t = t.rstrip('b'); pre, per = t[:-1].split('('); return (tuple(map(int, pre)), tuple(map(int, per)), int(g))
STATES = sorted(d['rule']); SID = {s: i for i, s in enumerate(STATES)}
SHAPE = [s.split('|')[0] for s in STATES]
BIN = [ploc(s.split('|')[1])[2] for s in STATES]; BOUT = [ploc(s.split('|')[2])[2] for s in STATES]
PROD = [[(int(it.split(':')[0]), SID[it.split(':')[1]]) for it in d['rule'][s]] for s in STATES]
for i, p in enumerate(PROD):
    assert sorted(c for c, _ in p) == (list(range(8)) if SHAPE[i] == 'D' else [0, 1, 3, 4, 5, 6, 7])
    assert all(SHAPE[t] == ('G' if c == 7 else 'D') for c, t in p)
first0 = lambda s: tile0(SHAPE[s], BIN[s]); last0 = lambda s: tile0(SHAPE[s], BOUT[s])
for s in range(len(STATES)):
    if SHAPE[s] == 'G': assert BIN[s] != BOUT[s] and share(tile0('G', 0), tile0('G', 1))
def key(j): sa, sb, (k, r, K) = j; return (sa, sb, k % 12, r, tuple(ev(V[m], K) for m in range(6)))
todo = []
for s, p in enumerate(PROD):
    for (a, sa), (c, sb) in zip(p, p[1:]): todo.append((sa, sb, comp(SO, inv(SO, TSYM[a]), TSYM[c])))
roots = len(todo); CL = {}
while todo:
    j = todo.pop(); kj = key(j)
    if kj in CL: continue
    CL[kj] = j; sa, sb, rho = j
    a, sa2 = PROD[sa][-1]; c, sb2 = PROD[sb][0]
    k, r, K = rho
    todo.append((sa2, sb2, comp(SO, comp(SO, inv(SO, TSYM[a]), (k, r, shiftM(K))), TSYM[c])))
bad = 0
for kj, (sa, sb, rho) in CL.items():
    if not share(last0(sa), [app(PO, (rho[0], rho[1], ev(V[0], rho[2])), p) for p in first0(sb)]): bad += 1
sib = set()
for s, p in enumerate(PROD):
    for (a, sa), (c, sb) in zip(p, p[1:]): sib.add(key((sa, sb, comp(SO, inv(SO, TSYM[a]), TSYM[c]))))
print(f'{sys.argv[1]}: {len(STATES)} states; {roots} junctions in productions, {len(sib)} distinct; closure under descent: '
      f'{len(CL)} junctions over {len({(k[2], k[3], k[4]) for k in CL})} relative positions; failing on single tiles: {bad}')
print('recurrence v6 = 9 v4 - 9 v2 + v0 holds exactly; keys compare six levels')
